module.exports = OmegaTarget
